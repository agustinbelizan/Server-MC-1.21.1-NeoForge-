execute as @a[tag=!spawnunico_hecho] run function spawnunico:go
