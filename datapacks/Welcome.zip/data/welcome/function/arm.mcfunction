# Marca al jugador para recibir la bienvenida en 80 ticks (4 segundos)
execute unless entity @s[tag=wlc_seen] run tag @s add wlc_first
tag @s add wlc_seen
scoreboard players reset @s wlc_left
scoreboard players operation @s wlc_session = #session wlc_session
scoreboard players set @s wlc_delay 80
