# Jugador que se desconecto antes (volvio a entrar en la misma sesion del servidor)
execute as @a[scores={wlc_left=1..}] run function welcome:arm
# Jugador que entra tras un reinicio/caida del servidor (o por primera vez)
execute as @a unless score @s wlc_session = #session wlc_session run function welcome:arm
# Cuenta atras para mostrar el cartel cuando el cliente ya cargo el mundo
execute as @a[scores={wlc_delay=1..}] at @s run function welcome:countdown
