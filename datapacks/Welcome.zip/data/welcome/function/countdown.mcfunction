scoreboard players remove @s wlc_delay 1
execute if score @s wlc_delay matches 0 run function welcome:show
