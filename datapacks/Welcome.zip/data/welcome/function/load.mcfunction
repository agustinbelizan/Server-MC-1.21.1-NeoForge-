# Se ejecuta al iniciar el servidor y con cada /reload
scoreboard objectives add wlc_left minecraft.custom:minecraft.leave_game
scoreboard objectives add wlc_delay dummy
scoreboard objectives add wlc_session dummy
# Nueva "sesion" solo si arranca el servidor vacio (no en un /reload con gente conectada)
execute unless entity @a run scoreboard players add #session wlc_session 1
execute unless score #session wlc_session matches 1.. run scoreboard players set #session wlc_session 1
