# Primera vez en el servidor
title @s times 20 110 40
title @s subtitle [{"text":"\u2726 ","color":"gold"},{"selector":"@s","color":"aqua","bold":true},{"text":" \u2726","color":"gold"}]
title @s title {"text":"BIENVENIDO","color":"gold","bold":true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.4 80 normal
particle minecraft:firework ~ ~0.5 ~ 0.3 0.3 0.3 0.15 60 normal
particle minecraft:end_rod ~ ~1 ~ 1 1 1 0.05 40 normal
tellraw @a ["",{"text":"\u2726 ","color":"gold"},{"selector":"@s","color":"aqua","bold":true},{"text":" llego al servidor por primera vez. \u00a1Denle la bienvenida!","color":"gold"}]
