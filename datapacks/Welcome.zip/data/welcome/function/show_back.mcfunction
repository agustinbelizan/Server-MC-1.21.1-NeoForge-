# Jugador que ya habia entrado antes
title @s times 20 90 30
title @s subtitle [{"text":"\u2726 ","color":"gold"},{"selector":"@s","color":"aqua","bold":true},{"text":" \u2726","color":"gold"}]
title @s title {"text":"BIENVENIDO DE VUELTA","color":"yellow","bold":true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.1
particle minecraft:end_rod ~ ~1 ~ 0.6 0.8 0.6 0.05 40 normal
particle minecraft:happy_villager ~ ~1 ~ 0.6 0.8 0.6 0.1 25 normal
