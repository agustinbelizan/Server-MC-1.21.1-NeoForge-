execute if entity @s[tag=wlc_first] run function welcome:show_first
execute unless entity @s[tag=wlc_first] run function welcome:show_back
tag @s remove wlc_first
